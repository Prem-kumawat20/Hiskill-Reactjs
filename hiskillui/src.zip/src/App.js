// import './App.css';
// import Sidebar from './Employee/components/Sidebar';
// import SkillTable from './Employee/components/SkillTable';
// import AddSkill from './Employee/components/AddSkill';

// function App() {
//   return (
//     <div className="App">
//       <div className="sidebar">
//         <Sidebar />
//       </div>
//       <div className="content">
//         {/* <AddSkill /> */}
//         <SkillTable/>
//       </div>
//     </div>
//   );
// }

// export default App;









// import './App.css';
// import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
// import Sidebar from './Employee/components/Sidebar.js';
// import SkillTable from './Employee/components/SkillTable.js';
// import AddSkill from './Employee/components/AddSkill.js';

// function App() {
//   return (
//     <Router>
//       <div className="App">
//         <div className="sidebar">
//           <Sidebar />
//         </div>
//         <div className="content">
//           <Routes>
//             <Route path="/home" component={SkillTable} />
//             <Route path="/myskills" component={SkillTable} />
//             <Route path="/addskill" component={AddSkill} />
//           </Routes>
//         </div>
//       </div>
//     </Router>
//   );
// }







import React from 'react';
import './App.css';
import Sidebar from './Employee/components/Sidebar';
import SkillTable from './Employee/components/SkillTable';
import AddSkill from './Employee/components/AddSkill';
import HomePage from './Employee/components/HomePage';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

function App() {
  return (
    <Router>
      <div className="App">
        <div className="sidebar">
          <Sidebar />
        </div>
        <div className="content">
          <Routes>
            <Route path="/home" element={<HomePage />} />
            <Route path="/skilltable" element={<SkillTable />} />
            <Route path="/addskill" element={<AddSkill />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;






















// import React from 'react';
// import { Routes, Route } from 'react-router-dom';
// import HomePage from './Employee/components/HomePage.js';
// import Sidebar from './Employee/components/Sidebar.js';
// import AddSkill from './Employee/components/AddSkill.js';
// import SkillTable from './Employee/components/SkillTable.js';

// function App() {
//   return (
//     <div>
//       <Sidebar />
//       <Routes>
//         <Route exact path="/home" component={HomePage} /> 
//         <Route exact path="/skilltable" component={SkillTable} />
//         <Route exact path="/addskill" component={AddSkill} />
//       </Routes>
//     </div>
//   );
// }

// export default App;


