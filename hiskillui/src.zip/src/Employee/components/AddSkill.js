import React, { useState } from 'react';
import axios from 'axios';
import {
  HvCard,
  HvCardContent,
  HvDatePicker,
  HvSlider,
  HvTypography
} from '@hitachivantara/uikit-react-core';

const Form = () => {
  const [employeeId, setEmployeeId] = useState('');
  const [employeeIdError, setEmployeeIdError] = useState('');
  const [skillId, setSkillId] = useState('');
  const [skillIdError, setSkillIdError] = useState('');
  const [proficiency, setProficiency] = useState(0);
  const [proficiencyError, setProficiencyError] = useState('');
  const [recentlyUsed, setRecentlyUsed] = useState(null);
  const [recentlyUsedError, setRecentlyUsedError] = useState('');
  const [createdBy, setCreatedBy] = useState('');
  const [createdByError, setCreatedByError] = useState('');
  const [proficiencyKey, setProficiencyKey] = useState(0); // Add proficiencyKey state



  const handleEmployeeIdChange = (event) => {
    setEmployeeId(event.target.value);
  };

  const handleSkillIdChange = (event) => {
    setSkillId(event.target.value);
  };

  const handleProficiencyChange = (value) => {
    setProficiency(value);
  };

  const handleRecentlyUsedChange = (date) => {
    setRecentlyUsed(date);
  };

  const handleCreatedByChange = (event) => {
    setCreatedBy(event.target.value);
  };
  

  const handleSubmit = (event) => {
    event.preventDefault();
    if (validateForm()) {
      const formData = {
        employeeId,
        skillId,
        proficiency,
        recentlyUsed,
        createdBy
      };
      setEmployeeId('');
      setSkillId('');
      setProficiency(0);
      setRecentlyUsed(null);
      setCreatedBy('');
      setProficiencyKey((prevKey) => prevKey + 1); // Update the key to reset the slider
      axios
        .post('/api/v1/skills', formData)
        .then((response) => {
          console.log('Form submitted:', response.data);
          setEmployeeId('');
          setSkillId('');
          setProficiency(0);
          setRecentlyUsed(null);
          setCreatedBy('');
        })
        .catch((error) => {
          console.error('Error submitting form:', error);
        });
    }
  };

  const validateForm = () => {
    let isValid = true;

    if (!employeeId) {
      setEmployeeIdError('Employee Id is required');
      isValid = false;
    } else {
      setEmployeeIdError('');
    }

    if (!skillId) {
      setSkillIdError('Skill Id is required');
      isValid = false;
    } else {
      setSkillIdError('');
    }

    if (proficiency === 0) {
      setProficiencyError('Proficiency is required');
      isValid = false;
    } else {
      setProficiencyError('');
    }

    if (!recentlyUsed) {
      setRecentlyUsedError('Recently Used date is required');
      isValid = false;
    } else {
      setRecentlyUsedError('');
    }
    if (!createdBy) {
      setCreatedByError('Created by is required');
      isValid = false;
    } else {
      setCreatedByError('');
    }

    return isValid;
  };

  const isFormValid = employeeId && skillId && proficiency !== 0 && recentlyUsed && createdBy;

  return (
    <>
      <HvTypography variant="3xlTitle" style={{ paddingTop: '10px', paddingRight: '50px' }}>
        Enter the details below
      </HvTypography>
      <div
        style={{
          margin: 20,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          paddingRight: '50px'
        }}
      >
        <HvCard
          bgcolor="atmo1"
          selectable
          selected
          statusColor="negative"
          style={{ width: 600, padding: '20px', height: '72vh' }}
        >
          <HvCardContent>
            <form onSubmit={handleSubmit}>
              <div
                style={{ marginBottom: '40px', marginTop: '20px', display: 'flex', alignItems: 'center' }}
              >
                <label
                  htmlFor="employeeId"
                  style={{ marginRight: '10px', fontWeight: 'bold', minWidth: '120px' }}
                >
                  Employee Id:
                </label>
                <input
                  type="text"
                  id="employeeId"
                  value={employeeId}
                  onChange={handleEmployeeIdChange}
                  required
                  style={{
                    width: '200px',
                    padding: '8px',
                    borderRadius: '4px',
                    border: '1px solid #ccc'
                  }}
                />
                {employeeIdError && (
                  <div style={{ color: 'red', marginLeft: '10px' }}>{employeeIdError}</div>
                )}
              </div>
              <div style={{ marginBottom: '40px', display: 'flex', alignItems: 'center' }}>
                <label htmlFor="skillId" style={{ marginRight: '10px', fontWeight: 'bold', minWidth: '120px' }}>
                  Skill Id:
                </label>
                <input
                  type="text"
                  id="skillId"
                  value={skillId}
                  onChange={handleSkillIdChange}
                  required
                  style={{
                    width: '200px',
                    padding: '8px',
                    borderRadius: '4px',
                    border: '1px solid #ccc'
                  }}
                />
                {skillIdError && (
                  <div style={{ color: 'red', marginLeft: '10px' }}>{skillIdError}</div>
                )}
              </div>
              <div style={{ marginBottom: '40px', display: 'flex', alignItems: 'center' }}>
                <label htmlFor="createdBy" style={{ marginRight: '10px', fontWeight: 'bold', minWidth: '120px' }}>
                  Created By:
                </label>
                <input
                  type="text"
                  id="createdBy"
                  value={createdBy}
                  onChange={handleCreatedByChange}
                  required
                  style={{
                    width: '200px',
                    padding: '8px',
                    borderRadius: '4px',
                    border: '1px solid #ccc',
                  }}
                />
                {createdByError && (
                  <div style={{ color: 'red', marginLeft: '10px' }}>{createdByError}</div>
                )}
              </div>
              <div style={{ marginBottom: '40px', display: 'flex', alignItems: 'center' }}>
                <label
                  htmlFor="proficiency"
                  style={{ marginRight: '10px', fontWeight: 'bold', minWidth: '120px' }}
                >
                  Proficiency:
                </label>
                <div style={{ flex: '1' }}>
                  <HvSlider
                    key={proficiencyKey} // Use key prop to re-render the slider and reset its value
                    id="proficiency"
                    markStep={1}
                    divisionQuantity={5}
                    maxPointValue={5}
                    defaultValues={[0]}
                    value={proficiency}
                    onChange={handleProficiencyChange}
                    style={{ width: '85%' }}
                    required
                  />
                </div>
              </div>
              {proficiencyError && (
                <div style={{ color: 'red', marginLeft: '10px' }}>{proficiencyError}</div>
              )}
              <div style={{ marginBottom: '40px', display: 'flex', alignItems: 'center' }}>
                <label htmlFor="recentlyUsed" style={{ marginRight: '10px', fontWeight: 'bold', minWidth: '120px' }}>
                  Recently Used:
                </label>
                <div style={{ flex: '1' }}>
                  <HvDatePicker
                    aria-label="Date"
                    id="recentlyUsed"
                    locale="en-US"
                    value={recentlyUsed}
                    onChange={handleRecentlyUsedChange}
                    onCancel={() => setRecentlyUsed(null)}
                    onClear={() => setRecentlyUsed(null)}
                    placeholder="Select date"
                    status="standBy"
                    placement="top"
                    style={{ width: '80%', paddingLeft: '10px' }}
                  />
                </div>
              </div>
              {recentlyUsedError && (
                <div style={{ color: 'red', marginLeft: '10px' }}>{recentlyUsedError}</div>
              )}
              <button
                type="submit"
                style={{
                  backgroundColor: isFormValid ? '#4CAF50' : '#ccc',
                  color: 'white',
                  padding: '10px 20px',
                  border: 'none',
                  borderRadius: '4px',
                  cursor: isFormValid ? 'pointer' : 'not-allowed',
                  fontWeight: 'bold'
                }}
                disabled={!isFormValid}
              >
                Submit
              </button>
            </form>
          </HvCardContent>
        </HvCard>
      </div>
    </>
  );
};

export default Form;
