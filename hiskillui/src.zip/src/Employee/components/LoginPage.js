import React from 'react'
import {HvButton, HvContainer, HvLogin, HvTypography, useTheme,HvInput} from "@hitachivantara/uikit-react-core";
// import {ThemeSwitcher } from "@hitachivantara/uikit-react-icons";
// import {Styled, StyledContainer, StyledLink, StyledThemeSwitcherContainer} from "./App.style";

import Styled from "@emotion/styled";

  
  const LoginPage = () => {
    
  
    return (
      <div
        style={{
          display: 'flex',
          height: '100vh'
        }}
      >
        <HvLogin background="https://lumada-design.github.io/uikit/master/assets/background-56514e96.png">
          <div>
          <HvTypography variant="title2">
            Welcome
          </HvTypography>
          {/* <Styled 
            label="Username"
            name="username"
            placeholder="Enter text"
          /> */}
          <HvInput
            label="Username"
            name="username"
            placeholder="Enter text"
          />

          </div>
        </HvLogin>
      </div>
    );
  };
  
  export default LoginPage;



// import { HvButton, theme } from "@hitachivantara/uikit-react-core";

// const LoginPage = () => (
//   <HvButton
//     variant="secondaryGhost"
//     onClick={() => {}}
//     style={{ backgroundColor: theme.colors.warning }}
//   >
//     Click me!
//   </HvButton>
// );

// export default LoginPage;