import React from 'react';
const Spinner = () => {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-around' }}>
      <r color="base_light" label="Primary button" variant="primary" />
      <r label="Secondary Subtle button" variant="secondarySubtle" />
      <r label="Secondary Ghost button" variant="secondaryGhost" />
    </div>
  );
};

export default Spinner;
