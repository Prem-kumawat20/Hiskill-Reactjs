import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  HvTableCell,
  HvTypography,
  HvCheckBox,
  HvTableRow,
  HvTableBody,
  HvTableHeader,
  HvTableHead,
  HvTableContainer,
  HvTable
} from "@hitachivantara/uikit-react-core";

export default function SkillTable() {
  const [skills, setSkills] = useState([]);
  const [selectedSkill, setSelectedSkill] = useState(null);
  const [newRating, setNewRating] = useState(0);
  const [newRecentlyUsed, setNewRecentlyUsed] = useState('');

  useEffect(() => {
    // axios.get("/api/v1/skills")
    //   .then((response) => {
    //     setSkills(response.data);
    //     console.log(response.data);
    //   })
    //   .catch((error) => {
    //     console.error(error);
    //   });
    const sampleData = [
      {
        "id": 1,
        "employeeId": "EMP001",
        "skillId": "SKL001",
        "rating": 3,
        "recentlyUsed": "2023-05-01"
      },
      {
        "id": 2,
        "employeeId": "EMP002",
        "skillId": "SKL002",
        "rating": 4,
        "recentlyUsed": "2023-05-15"
      },
      {
        "id": 3,
        "employeeId": "EMP003",
        "skillId": "SKL003",
        "rating": 2,
        "recentlyUsed": "2023-05-10"
      }
    ];

    setSkills(sampleData);
  }, []);

  const handleUpdateSkill = (skillId) => {
    const skillToUpdate = skills.find((skill) => skill.id === skillId);

    const updatedSkill = {
      ...skillToUpdate,
      rating: newRating,
      recentlyUsed: newRecentlyUsed, 
    };

    const updatedSkills = skills.map((skill) => (skill.id === skillId ? updatedSkill : skill));

    setSkills(updatedSkills);

    axios.put(`/api/v1/skills/${skillId}`, updatedSkill)
      .then((response) => {
        console.log('Skill updated:', response.data);
      })
      .catch((error) => {
        console.error('Error updating skill:', error);
        setSkills(skills);
      });

    setSelectedSkill(null);
    setNewRating(0);
    setNewRecentlyUsed('');
  };

  return (
    <div>
      <div className="skill-table" style={{ width: 900}}>
        <HvTypography variant="3xlTitle">
          My Skills
        </HvTypography>
        <div style={{ marginTop: "20px" }}>
          <HvTableContainer>
            <HvTable>
              <HvTableHead>
                <HvTableRow>
                  <HvTableCell variant="checkbox" />
                  <HvTableHeader>Employee Id</HvTableHeader>
                  <HvTableHeader>Skill Id</HvTableHeader>
                  <HvTableHeader>Proficiency</HvTableHeader>
                  <HvTableHeader>Recently Used</HvTableHeader>
                  <HvTableHeader>Actions</HvTableHeader> 
                </HvTableRow>
              </HvTableHead>
              <HvTableBody>
                {
                  skills.map((skill) => (
                    <HvTableRow key={skill.id} hover>
                      <HvTableCell variant="checkbox">
                        <HvCheckBox onClick={() => {}} />
                      </HvTableCell>
                      <HvTableCell>{skill.employeeId}</HvTableCell>
                      <HvTableCell>{skill.skillId}</HvTableCell>
                      <HvTableCell>{skill.rating}</HvTableCell>
                      <HvTableCell>{skill.recentlyUsed}</HvTableCell>
                      <HvTableCell>
                        {selectedSkill === skill.id ? (
                          <div>
                            <input
                              type="number"
                              value={newRating}
                              onChange={(e) => setNewRating(parseInt(e.target.value))}
                            />
                            <input
                              type="text"
                              value={newRecentlyUsed}
                              onChange={(e) => setNewRecentlyUsed(e.target.value)}
                            />
                            <button onClick={() => handleUpdateSkill(skill.id)}>Update</button>
                          </div>
                        ) : (
                          <button onClick={() => setSelectedSkill(skill.id)}>Edit</button>
                        )}
                      </HvTableCell>
                    </HvTableRow>
                  ))
                }
              </HvTableBody>
            </HvTable>
          </HvTableContainer>
        </div>
      </div>
    </div>
  );
}
