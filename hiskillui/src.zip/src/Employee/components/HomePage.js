import React from 'react'
import {HvTypography} from "@hitachivantara/uikit-react-core";
export default function HomePage() {
  return (
    <div 
  style={{
    width: 400,
    alignItems: 'center'
  }}
>
  <HvTypography
    variant="title1"
  >
    This is Home Page !!!
  </HvTypography>
</div>
  )
}
